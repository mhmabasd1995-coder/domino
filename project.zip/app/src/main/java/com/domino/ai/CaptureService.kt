package com.domino.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var bubble: TextView? = null
    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val thread = HandlerThread("domino").apply { start() }
    private val work = Handler(thread.looper)
    private val tracker = Tracker()
    private var capW = 720
    private var capH = 1604
    private var running = false
    private var lastSig = ""
    private var stable = 0
    private var doneSig = ""
    private var lastHand: List<Int> = emptyList()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY
        goForeground()
        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("data")
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        capW = 720
        capH = (720f * dm.heightPixels / dm.widthPixels).toInt()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, ui)
        projection = proj
        val rd = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = rd
        vdisplay = proj.createVirtualDisplay(
            "domino", capW, capH, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rd.surface, null, null
        )
        showBubble(dm.heightPixels)
        running = true
        work.postDelayed(tick, 1500)
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("dom", "Domino AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "dom")
            .setContentTitle("Domino AI شغّال")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun showBubble(screenH: Int) {
        ui.post {
            val tv = TextView(this)
            tv.setTextColor(Color.WHITE)
            tv.setBackgroundColor(Color.argb(210, 16, 24, 32))
            tv.setPadding(28, 16, 28, 16)
            tv.textSize = 16f
            tv.text = "Domino AI: جاري القراءة..."
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.y = (screenH * 0.155f).toInt()
            wm.addView(tv, lp)
            bubble = tv
        }
    }

    private fun setText(s: String) {
        ui.post { bubble?.text = s }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                step()
            } catch (e: Throwable) {
                setText("خطأ: " + e.message)
            }
            work.postDelayed(this, 900)
        }
    }

    private fun step() {
        val img = reader?.acquireLatestImage() ?: return
        val px = IntArray(capW * capH)
        try {
            val plane = img.planes[0]
            val buf = plane.buffer
            val rs = plane.rowStride
            for (y in 0 until capH) {
                for (x in 0 until capW) {
                    val o = y * rs + x * 4
                    val r = buf.get(o).toInt() and 255
                    val g = buf.get(o + 1).toInt() and 255
                    val b = buf.get(o + 2).toInt() and 255
                    px[y * capW + x] = (r shl 16) or (g shl 8) or b
                }
            }
        } finally {
            img.close()
        }
        val o = Reader.read(px, capW, capH)
        if (!o.valid) return
        val sig = o.sig()
        if (sig == lastSig) stable++ else { lastSig = sig; stable = 1 }
        if (stable < 2 || sig == doneSig) return
        doneSig = sig
        lastHand = o.hand
        val changed = tracker.update(o)
        if (!tracker.started) { setText(tracker.note); return }
        if (!changed) return
        setText("جاري الحساب...")
        val s = Engine.suggest(tracker, 1100)
        setText(describe(s))
    }

    private fun tileTxt(t: Int) = "[" + (t / 7) + "|" + (t % 7) + "]"

    private fun describe(s: Sug?): String {
        val by = maxOf(0, 28 - tracker.mine.size - tracker.table.size - tracker.opp)
        val head = when {
            s == null -> "ما عندك أحجار"
            s.kind == 'D' -> "اسحب حجر من المخزون"
            s.kind == 'X' -> "pass"
            else -> {
                val pos = lastHand.indexOf(s.tile) + 1
                val where = if (s.end < 0) "افتح بها" else "على الرقم " + s.end
                "العب " + tileTxt(s.tile) + " " + where + "\n(الحجر رقم " + pos + " من اليسار)"
            }
        }
        val ends = if (tracker.left < 0) "" else "\nالطرفان: " + tracker.left + " و " + tracker.right
        val extra = if (tracker.note.isEmpty()) "" else "\n" + tracker.note
        return head + ends + "\nالخصم: " + tracker.opp + " | المخزون: " + by + extra
    }

    override fun onDestroy() {
        running = false
        work.removeCallbacksAndMessages(null)
        vdisplay?.release()
        reader?.close()
        projection?.stop()
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        thread.quitSafely()
        super.onDestroy()
    }
}
