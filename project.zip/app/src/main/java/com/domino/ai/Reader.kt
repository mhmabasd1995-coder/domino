package com.domino.ai

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Pip(val c: Int, val x: Float, val y: Float)

/** ما قرأناه من لقطة وحدة. مفتاح الحجر = صغير*7 + كبير */
class Obs(
    val hand: List<Int>,
    val opp: Int,
    val pips: IntArray,
    val valid: Boolean
) {
    fun sig(): String = hand.joinToString(",") + "|" + opp + "|" + pips.joinToString(",")
}

object Reader {
    // ألوان النقاط: 1 أحمر، 2 برتقالي، 3 أخضر، 4 أزرق، 5 بنفسجي، 6 رمادي
    private fun label(r: Int, g: Int, b: Int): Int {
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val sat = mx - mn
        if (sat > 70) {
            val d = sat.toFloat()
            var h = if (mx == r) 60f * (((g - b) / d + 6f) % 6f)
            else if (mx == g) 60f * ((b - r) / d + 2f)
            else 60f * ((r - g) / d + 4f)
            if (h < 0f) h += 360f
            return when {
                h < 12f || h > 345f -> 1
                h < 45f -> 2
                h >= 70f && h < 170f -> 3
                h >= 190f && h < 250f -> 4
                h >= 250f && h < 330f -> 5
                else -> 0
            }
        }
        if (sat < 45 && mx >= 52 && mx < 138 && abs(r - g) < 22 && abs(g - b) < 22) return 6
        return 0
    }

    private fun blobs(px: IntArray, w: Int, yA: Int, yB: Int): List<Pip> {
        val h = yB - yA
        val lab = ByteArray(w * h)
        for (y in 0 until h) {
            val row = (y + yA) * w
            for (x in 0 until w) {
                val p = px[row + x]
                lab[y * w + x] = label((p shr 16) and 255, (p shr 8) and 255, p and 255).toByte()
            }
        }
        val out = ArrayList<Pip>()
        var stack = IntArray(8192)
        for (start in lab.indices) {
            val c = lab[start].toInt()
            if (c == 0) continue
            var sp = 0
            stack[sp++] = start
            lab[start] = 0
            var area = 0
            var sx = 0L
            var sy = 0L
            var x0 = w
            var x1 = 0
            var y0 = h
            var y1 = 0
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w
                val y = i / w
                area++
                sx += x
                sy += y
                if (x < x0) x0 = x
                if (x > x1) x1 = x
                if (y < y0) y0 = y
                if (y > y1) y1 = y
                if (sp + 4 >= stack.size) stack = stack.copyOf(stack.size * 2)
                if (x > 0 && lab[i - 1].toInt() == c) { lab[i - 1] = 0; stack[sp++] = i - 1 }
                if (x < w - 1 && lab[i + 1].toInt() == c) { lab[i + 1] = 0; stack[sp++] = i + 1 }
                if (y > 0 && lab[i - w].toInt() == c) { lab[i - w] = 0; stack[sp++] = i - w }
                if (y < h - 1 && lab[i + w].toInt() == c) { lab[i + w] = 0; stack[sp++] = i + w }
            }
            val bw = x1 - x0 + 1
            val bh = y1 - y0 + 1
            if (area in 22..520 && bw in 4..32 && bh in 4..32) {
                val ratio = bw.toFloat() / bh
                if (ratio >= 0.6f && ratio <= 1.6f && area.toFloat() / (bw * bh) >= 0.5f) {
                    out.add(Pip(c, sx.toFloat() / area, sy.toFloat() / area + yA))
                }
            }
        }
        return out
    }

    private const val MAXP = 93.3f / 720f
    private const val SPAN = (705f - 14f - 64f) / 720f

    private fun centers(n: Int, w: Int): FloatArray {
        val pitch = if (n < 2) MAXP else min(MAXP, SPAN / (n - 1))
        return FloatArray(n) { w / 2f + (it - (n - 1) / 2f) * pitch * w }
    }

    /** قيمة نص الحجر من نقاطه: -1 إذا غير متسقة */
    private fun half(ps: List<Pip>): Int {
        if (ps.isEmpty()) return 0
        val cnt = IntArray(7)
        for (p in ps) cnt[p.c]++
        var best = 1
        for (c in 2..6) if (cnt[c] > cnt[best]) best = c
        if (cnt[best] != ps.size) return -1
        return if (ps.size == best) best else -1
    }

    fun read(px: IntArray, w: Int, h: Int): Obs {
        val hp = blobs(px, w, (h * 0.895f).toInt(), h)
        val tp = blobs(px, w, (h * 0.27f).toInt(), (h * 0.80f).toInt())
        var valid = true

        val hand = ArrayList<Int>()
        if (hp.isNotEmpty()) {
            var best = -1
            for (n in 1..14) {
                val cs = centers(n, w)
                var outside = 0
                for (p in hp) {
                    var m = 1e9f
                    for (c in cs) m = min(m, abs(p.x - c))
                    if (m > 0.03f * w) outside++
                }
                if (outside == 0) { best = n; break }
            }
            if (best < 0) {
                valid = false
            } else {
                val cs = centers(best, w)
                val top = Array(best) { ArrayList<Pip>() }
                val bot = Array(best) { ArrayList<Pip>() }
                for (p in hp) {
                    var bi = 0
                    for (i in 1 until best) if (abs(p.x - cs[i]) < abs(p.x - cs[bi])) bi = i
                    if (p.y < h * 0.944f) top[bi].add(p) else bot[bi].add(p)
                }
                for (i in 0 until best) {
                    val a = half(top[i])
                    val b = half(bot[i])
                    if (a < 0 || b < 0) { valid = false; hand.add(0) } else hand.add(min(a, b) * 7 + max(a, b))
                }
            }
        }

        val cnt = IntArray(7)
        for (p in tp) cnt[p.c]++
        for (c in 1..6) if (cnt[c] % c != 0) valid = false

        val oy = (h * 0.115f).toInt()
        var lo = -1
        var hi = -1
        for (x in (w * 0.25f).toInt() until (w * 0.74f).toInt()) {
            val p = px[oy * w + x]
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            val sat = max(r, max(g, b)) - min(r, min(g, b))
            if (sat < 22 && (r + g + b) / 3 > 100) {
                if (lo < 0) lo = x
                hi = x
            }
        }
        val opp = if (lo < 0) 0 else ((hi - lo + 1) / (43f * w / 720f)).roundToInt()
        return Obs(hand, opp, cnt, valid)
    }
}
