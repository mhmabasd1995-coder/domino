package com.domino.ai

import java.util.Random

class Sug(val kind: Char, val tile: Int, val end: Int)

object Engine {
    private val rnd = Random()

    private class S(
        val h0: ArrayList<Int>, val h1: ArrayList<Int>, val by: ArrayList<Int>,
        var l: Int, var r: Int, var turn: Int, var passes: Int
    ) {
        fun copy() = S(ArrayList(h0), ArrayList(h1), ArrayList(by), l, r, turn, passes)
    }

    private class Mv(val k: Char, val t: Int, val side: Int)

    private fun pips(t: Int) = t / 7 + t % 7

    private fun legal(s: S): ArrayList<Mv> {
        val h = if (s.turn == 0) s.h0 else s.h1
        val ms = ArrayList<Mv>()
        if (s.l < 0) {
            for (t in h) ms.add(Mv('P', t, 0))
            return ms
        }
        for (t in h) {
            val a = t / 7
            val b = t % 7
            val l = a == s.l || b == s.l
            val r = a == s.r || b == s.r
            if (l) ms.add(Mv('P', t, 0))
            if (r && !(l && s.l == s.r)) ms.add(Mv('P', t, 1))
        }
        if (ms.isEmpty()) ms.add(if (s.by.isNotEmpty()) Mv('D', 0, 0) else Mv('X', 0, 0))
        return ms
    }

    private fun play(s: S, m: Mv) {
        val h = if (s.turn == 0) s.h0 else s.h1
        if (m.k == 'P') {
            h.remove(m.t)
            val a = m.t / 7
            val b = m.t % 7
            if (s.l < 0) { s.l = a; s.r = b }
            else if (m.side == 0) s.l = if (a == s.l) b else a
            else s.r = if (a == s.r) b else a
            s.passes = 0
            s.turn = 1 - s.turn
        } else if (m.k == 'D') {
            h.add(s.by.removeAt(s.by.size - 1))
        } else {
            s.passes++
            s.turn = 1 - s.turn
        }
    }

    private fun over(s: S) = s.h0.isEmpty() || s.h1.isEmpty() || (s.by.isEmpty() && s.passes >= 2)

    private fun value(s: S): Double {
        var a = 0
        for (t in s.h0) a += pips(t)
        var b = 0
        for (t in s.h1) b += pips(t)
        val w: Int
        val pts: Int
        if (s.h0.isEmpty()) { w = 0; pts = b }
        else if (s.h1.isEmpty()) { w = 1; pts = a }
        else if (a == b) return 0.0
        else { w = if (a < b) 0 else 1; pts = Math.abs(a - b) }
        return (if (w == 0) 1.0 else -1.0) * (1.0 + pts / 60.0)
    }

    private fun heur(s: S, ms: ArrayList<Mv>, noise: Double): Mv {
        if (ms[0].k != 'P') return ms[0]
        val h = if (s.turn == 0) s.h0 else s.h1
        var best = ms[0]
        var bs = -1e9
        for (m in ms) {
            val a = m.t / 7
            val b = m.t % 7
            var keep = 0
            if (s.l >= 0) {
                val end = if (m.side == 0) s.l else s.r
                val o = if (a == end) b else a
                for (x in h) if (x != m.t && (x / 7 == o || x % 7 == o)) keep++
            }
            val sc = (a + b) * 0.6 + (if (a == b) 2.5 else 0.0) + keep * 1.5 + rnd.nextDouble() * noise
            if (sc > bs) { bs = sc; best = m }
        }
        return best
    }

    private fun determinize(tr: Tracker, by: Int): S {
        val played = HashSet<Int>(tr.table)
        val mine = HashSet<Int>(tr.mine)
        val un = ArrayList<Int>()
        for (a in 0..6) for (b in a..6) {
            val k = a * 7 + b
            if (k !in played && k !in mine) un.add(k)
        }
        java.util.Collections.shuffle(un, rnd)
        val ok = ArrayList<Int>()
        val bad = ArrayList<Int>()
        for (k in un) {
            if ((k / 7) in tr.cant || (k % 7) in tr.cant) bad.add(k) else ok.add(k)
        }
        val n = minOf(tr.opp, un.size)
        var kb = if (tr.drawn > 0) rnd.nextInt(minOf(tr.drawn, bad.size, n) + 1) else 0
        kb = minOf(maxOf(kb, n - ok.size), bad.size, n)
        val hand = ArrayList<Int>()
        for (i in 0 until n - kb) hand.add(ok[i])
        for (i in 0 until kb) hand.add(bad[i])
        val hs = HashSet<Int>(hand)
        val rest = ArrayList<Int>()
        for (k in un) if (k !in hs) rest.add(k)
        java.util.Collections.shuffle(rest, rnd)
        return S(ArrayList(tr.mine), hand, rest, tr.left, tr.right, 0, 0)
    }

    fun suggest(tr: Tracker, ms: Long): Sug? {
        if (tr.mine.isEmpty()) return null
        val by = maxOf(0, 28 - tr.mine.size - tr.table.size - tr.opp)
        val fakeBy = ArrayList<Int>()
        for (i in 0 until by) fakeBy.add(0)
        val base = S(ArrayList(tr.mine), ArrayList(), fakeBy, tr.left, tr.right, 0, 0)
        val moves = legal(base)
        var pick = 0
        if (moves.size > 1) {
            val tot = DoubleArray(moves.size)
            val end = System.currentTimeMillis() + ms
            do {
                val det = determinize(tr, by)
                for (i in moves.indices) {
                    val s = det.copy()
                    play(s, moves[i])
                    var guard = 0
                    while (!over(s) && guard < 200) {
                        play(s, heur(s, legal(s), 1.5))
                        guard++
                    }
                    tot[i] += value(s)
                }
            } while (System.currentTimeMillis() < end)
            for (i in tot.indices) if (tot[i] > tot[pick]) pick = i
        }
        val m = moves[pick]
        val endNum = if (tr.left < 0) -1 else if (m.side == 0) tr.left else tr.right
        return Sug(m.k, m.t, endNum)
    }
}
