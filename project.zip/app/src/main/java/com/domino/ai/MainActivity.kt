package com.domino.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val info = TextView(this)
        info.text = "Domino AI\n\n1) اضغط ابدأ ووافق على العرض فوق التطبيقات وتصوير الشاشة.\n" +
            "2) افتح اللعبة من أول الجولة (قبل أي حركة).\n" +
            "3) تظهر الحركة المقترحة بشريط صغير فوق الطاولة. تلعبها بإيدك."
        info.textSize = 16f
        info.setPadding(40, 60, 40, 30)
        val start = Button(this)
        start.text = "ابدأ"
        start.setOnClickListener { begin() }
        val stop = Button(this)
        stop.text = "إيقاف"
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)) }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(info)
        box.addView(start)
        box.addView(stop)
        setContentView(box)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
