package com.domino.ai

/** يتتبع اللعبة من فروقات اللقطات: أي حجر نزل، مين سحب، وأطراف الطاولة. */
class Tracker {
    var started = false
    var mine: MutableList<Int> = ArrayList()
    var opp = 7
    val table = ArrayList<Int>()
    var left = -1
    var right = -1
    val cant = HashSet<Int>()
    var drawn = 0
    var lastPips = IntArray(7)
    var note = ""

    private fun halves(p: IntArray): Int {
        var s = 0
        for (v in 1..6) s += p[v] / v
        return s
    }

    private fun reset(o: Obs) {
        started = true
        mine = ArrayList(o.hand)
        opp = 7
        table.clear()
        left = -1
        right = -1
        cant.clear()
        drawn = 0
        lastPips = IntArray(7)
        note = ""
    }

    private fun place(t: Int) {
        table.add(t)
        val a = t / 7
        val b = t % 7
        if (left < 0) { left = a; right = b; return }
        val canL = a == left || b == left
        val canR = a == right || b == right
        if (canL && canR && left != right) {
            note = "الحجر يركب على الطرفين: افترضت الطرف الأول، تأكد"
            left = if (a == left) b else a
        } else if (canL) {
            left = if (a == left) b else a
        } else if (canR) {
            right = if (a == right) b else a
        } else {
            note = "حجر ما يركب على الطرفين، القراءة غلط؟"
        }
    }

    /** يرجّع true إذا تغيّر الوضع وصار لازم نحسب اقتراح جديد */
    fun update(o: Obs): Boolean {
        if (!o.valid) return false
        val h = halves(o.pips)
        if (o.hand.size == 7 && o.opp == 7 && h == 0 && (!started || table.isNotEmpty())) {
            reset(o)
            return true
        }
        if (!started) {
            if (o.hand.size == 7 && o.opp == 6 && h <= 2) {
                reset(o)
            } else {
                note = "ابدأ التطبيق من أول الجولة (قبل أول حركة)"
                return false
            }
        }
        var changed = false
        note = ""
        val removed = mine.filter { it !in o.hand }
        val added = o.hand.filter { it !in mine }
        val dn = IntArray(7)
        for (v in 1..6) dn[v] = (o.pips[v] - lastPips[v]) / v

        if (removed.size == 1 && added.isEmpty()) {
            val t = removed[0]
            place(t)
            if (t / 7 > 0) dn[t / 7]--
            if (t % 7 > 0) dn[t % 7]--
            changed = true
        } else if (added.size == 1 && removed.isEmpty()) {
            changed = true
        } else if (removed.isNotEmpty() || added.isNotEmpty()) {
            note = "تغيّر غير واضح بأحجارك"
            changed = true
        }
        mine = ArrayList(o.hand)

        if (o.opp == opp - 1) {
            val vals = ArrayList<Int>()
            var bad = false
            for (v in 1..6) {
                if (dn[v] < 0) bad = true
                for (k in 0 until maxOf(dn[v], 0)) vals.add(v)
            }
            while (vals.size < 2) vals.add(0)
            if (bad || vals.size != 2) {
                note = "ما قدرت أعرف حجر الخصم"
            } else {
                val key = minOf(vals[0], vals[1]) * 7 + maxOf(vals[0], vals[1])
                if (key in table || key in mine) note = "حجر الخصم المقروء غير منطقي"
                else place(key)
            }
            changed = true
        } else if (o.opp == opp + 1) {
            if (left >= 0) { cant.add(left); cant.add(right) }
            drawn++
            changed = true
        } else if (o.opp != opp) {
            note = "تغيّر غير واضح بأحجار الخصم"
            changed = true
        }
        opp = o.opp
        lastPips = o.pips.copyOf()
        return changed
    }
}
